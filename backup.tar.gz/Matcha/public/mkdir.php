<?php
var_dump (mkdir('../uploads'));

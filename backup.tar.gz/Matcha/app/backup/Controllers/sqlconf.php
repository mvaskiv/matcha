<?php

return (array(
'dsn' => 'mysql:host=localhost;dbname=matcha_db',
'user' => 'root',
'password' => 'qweqwe'));

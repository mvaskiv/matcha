<?php

return (array(
'dsn' => 'mysql:host=fdb21.awardspace.net;dbname=2700527_camagru',
'user' => '2700527_camagru',
'password' => 'qweqwe123'));
